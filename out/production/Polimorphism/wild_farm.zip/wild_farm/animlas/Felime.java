package wild_farm.animlas;

public abstract class Felime extends Mammal{
    protected Felime(String animalType,String animalName, double animalWeight, int foodEaten, String livingRegion) {
        super( animalType,animalName, animalWeight, foodEaten, livingRegion);
    }
}
