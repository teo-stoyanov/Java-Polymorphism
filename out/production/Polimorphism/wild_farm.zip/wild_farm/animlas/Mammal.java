package wild_farm.animlas;

public abstract class Mammal extends Animal{

    String livingRegion;
    protected Mammal( String animalType,String animalName, double animalWeight, int foodEaten , String livingRegion) {
        super( animalType,animalName, animalWeight, foodEaten);
        this.livingRegion = livingRegion;
    }
}
