package wild_farm.food;

public class Vegetable extends Food {
    public Vegetable(int quantity) {
        super(quantity);
    }
}
